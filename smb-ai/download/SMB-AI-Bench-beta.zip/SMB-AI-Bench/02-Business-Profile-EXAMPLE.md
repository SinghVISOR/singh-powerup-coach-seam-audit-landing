# My Business Profile: EXAMPLE (fictional business)
*This is a filled-in example to show you the level of detail that works. Replace everything with your own business.*

## 1. The basics
- **Business name:** Harbor Line Plumbing & Heating
- **What we sell:** Residential and light-commercial plumbing repairs, water heater installs, and annual maintenance plans.
- **Where we operate:** Jacksonville and St. Johns County, FL
- **Team size:** Me + 6 technicians + 1 office manager
- **My name and role:** Dana Ruiz, owner

## 2. Our customers
- **Ideal customer:** Homeowners and small property managers who want a reliable plumber they can call again; property managers with 5–40 units are our best accounts.
- **Customers we don't want:** Price shoppers wanting phone quotes, out-of-area jobs (south of Palm Coast), new-construction bids.
- **Refer out-of-scope work to:** new construction → Coastline Builders Plumbing; south of Palm Coast → Flagler Pro Plumbing
- **Average job size:** $450 repair; $2,800 water heater install; maintenance plan $199/yr.

## 3. VIP list: always comes to me first
1. Coastal Keys Property Management
2. St. Augustine Dental Group
3. Riverside Apartments (Mark Chen)
4. Any customer with an open warranty claim
5. Anyone who mentions a lawyer, insurance claim, or water damage

- **Clients with a past dispute:** Bayview Condos (billing dispute, spring 2026; always cc their accounts team)

## 4. How we sound
- **Three words:** friendly, straight-talking, local
- **Never use:** "per our policy," "unfortunately," corporate jargon
- **Sign-off:** "Thanks, Dana, Harbor Line Plumbing"
- **Sample email:**
> Hi Mrs. Patel, thanks for having us out Tuesday. The new valve is in and holding pressure fine. If you see any drips this week, just text me at the number below and we'll swing by, no charge. Thanks, Dana, Harbor Line Plumbing

## 5. Money rules
- **Payment terms:** Due on completion for homeowners; net 15 for property managers
- **Late fee:** 1.5% per month after 30 days (property managers only, stated on invoice)
- **Rate card:** Service call $95; labor $125/hr; water heater install from $2,400 (see price sheet)
- **Discounts allowed without asking:** 10% for maintenance-plan members only
- **Needs my approval:** any refund, credit or discount above $100; any job quote over $3,000
- **Invoice amount that comes to me:** anything over $3,000
- **Vendor contracts over this amount come to me:** $2,000 total
- **Cash cushion:** never below $10,000 (one payroll run)
- **Regular monthly costs:** rent $3,100 (1st), truck loans $2,400 (15th), insurance $1,150 (5th), software about $600, materials about $8,000

## 6. Tools we use
- **Email:** Gmail
- **Accounting:** QuickBooks Online
- **CRM:** Housecall Pro
- **Files/chat:** Google Drive, text messages

## 7. My approval rules (Mark the Line)
- **Never sent without my OK:** anything to a VIP; refunds; any reply to a bad review
- **Only I decide:** pricing exceptions, hiring, warranty claims, anything legal
- **A specialist may finish on its own:** drafts, summaries, sorting, checklists

## 8. This quarter
- **Top 3 goals:** sign 40 new maintenance plans; get receivables under 30 days; hire one more tech
- **What's eating my week:** chasing invoices, answering the same customer questions, writing quotes at night
