# My Business Profile
*SMB.AI Bench: fill this in once, then upload it to every specialist. Every specialist reads it before it does anything. Plain sentences are fine. Leave a line blank if it doesn't apply. The more you fill in, the less you'll have to explain later.*

---

## 1. The basics
- **Business name:**
- **What we sell (one or two sentences):**
- **Where we operate (city, region, online):**
- **Team size:** (e.g., just me / me + 3 / 12 people)
- **My name and role:**

## 2. Our customers
- **Ideal customer (who buys, why they buy):**
- **Customers we don't want (bad-fit signs):**
- **Average job or order size:**
- **Who we refer out-of-area or out-of-scope work to:**

## 3. VIP list: always comes to me first
*Specialists will never draft anything for these people without flagging it to you first. List your top clients, key partners, and anyone sensitive.*
1.
2.
3.
4.
5.

- **Clients with a past dispute or special handling:**

## 4. How we sound
- **Three words for our tone:** (e.g., warm, direct, no jargon)
- **Words or phrases we never use:**
- **How I sign off emails:**
- **Paste one or two emails you wrote that sound like you:**

> (paste here)

## 5. Money rules
- **Payment terms:** (e.g., net 15, 50% deposit)
- **Late fee policy (if any):**
- **Prices or rate card (or "see attached"):**
- **Discounts I allow without asking me:** (e.g., none / up to 5%)
- **Spending or refund amount that always needs my approval:**
- **Invoice or job amount that always comes to me:**
- **Cash cushion I never want to drop below:**
- **Regular monthly costs (rent, loans, insurance, software, materials):**
- **Vendor contracts over this amount come to me:**

## 6. Tools we use
- **Email:** (Gmail, Outlook)
- **Accounting:** (QuickBooks, Xero, Wave, spreadsheet)
- **CRM or customer list:** (HubSpot, spreadsheet, none)
- **Calendar, files, chat:** (Google, Microsoft 365, Slack)

## 7. My approval rules (Mark the Line)
*These are your standing rules. Specialists follow them every time.*
- **Never sent without my OK:** (default: everything that leaves the business)
- **Decisions only I make:** (e.g., pricing, hiring, refunds, legal)
- **Things a specialist may finish on its own:** (default: drafts, summaries, lists)

## 8. This quarter
- **Our top 3 goals right now:**
- **What's eating my week:**
