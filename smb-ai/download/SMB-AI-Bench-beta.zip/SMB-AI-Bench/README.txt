THE SMB.AI BENCH, BETA 1.0
Free for beta owners. Feedback: info@singhpowerupcoach.com

Start with 00-Setup-Guide.pdf.

1. Fill in 01-Business-Profile-TEMPLATE.md (see the EXAMPLE file).
2. Option A: create one Claude Project per specialist, paste the matching file from Projects/ into the project instructions, and upload your Business Profile.
   Option B: upload a .zip from Skills/ under Customize > Skills (don't unzip it).
3. Type 'start' and get your first win this week.

Built for use with Claude. Not affiliated with or endorsed by Anthropic.
Not legal, tax or financial advice. Always review before you send.

(c) 2026 Singh Leadership / SMB.AI. For your own business use only. Please don't resell or redistribute.
